//
//  ViewController.swift
//  Default Share
//
//  Created by Rp on 25/10/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func clickOn(){
        
      //  let strText = "Hello Eveyone Good Morning"
        
    //    let str = "http://pupilpost.com/e/Wvxeejf=\()/feed"
        
        let arr = [#imageLiteral(resourceName: "bb.jpg")]
        
        let activityController = UIActivityViewController.init(activityItems: arr, applicationActivities: nil)
        
        activityController.excludedActivityTypes = [.postToFacebook,.airDrop,.assignToContact,.copyToPasteboard,.print]
        
        self.present(activityController, animated: true, completion: nil)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

